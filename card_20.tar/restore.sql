--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.1
-- Dumped by pg_dump version 15.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'C.UTF-8';


ALTER DATABASE postgres OWNER TO postgres;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- Name: postgres; Type: DATABASE PROPERTIES; Schema: -; Owner: postgres
--

ALTER DATABASE postgres SET "app.settings.jwt_secret" TO 'bK25W+HcNtZx94r87flJvyMx5sku1K+HxYsa53jWpQ9eUU8fbQZkr49qZ/HVs1V6lqyO6lqzBoA8kduYHMAySw==';
ALTER DATABASE postgres SET "app.settings.jwt_exp" TO '3600';


\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: card_20; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.card_20 (
    id integer NOT NULL,
    title character varying(255),
    descrip character varying(255),
    category character varying(255),
    img character varying(255),
    remote_img character varying(255)
);


ALTER TABLE public.card_20 OWNER TO postgres;

--
-- Data for Name: card_20; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.card_20 (id, title, descrip, category, img, remote_img) FROM stdin;
\.
COPY public.card_20 (id, title, descrip, category, img, remote_img) FROM '$$PATH$$/3668.dat';

--
-- Name: card_20 card_20_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.card_20
    ADD CONSTRAINT card_20_pkey PRIMARY KEY (id);


--
-- Name: DATABASE postgres; Type: ACL; Schema: -; Owner: postgres
--

GRANT ALL ON DATABASE postgres TO dashboard_user;


--
-- Name: TABLE card_20; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public.card_20 TO anon;
GRANT ALL ON TABLE public.card_20 TO authenticated;
GRANT ALL ON TABLE public.card_20 TO service_role;


--
-- PostgreSQL database dump complete
--

